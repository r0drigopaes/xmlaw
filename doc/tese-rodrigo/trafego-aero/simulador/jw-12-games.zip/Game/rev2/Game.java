// Game.java

import jgame.*;

public class Game extends JGEngine
{
   final static int NTILESX = 1;
   final static int NTILESY = 1;
   final static int TILEW = 800;
   final static int TILEH = 600;

   public Game ()
   {
      initEngineApplet (NTILESX, NTILESY, TILEW, TILEH, null, null, null);
   }

   public Game (int width, int height)
   {
      initEngine (NTILESX, NTILESY, TILEW, TILEH, null, null, null, width,
                  height);
   }

   public void initGame ()
   {
      // Hide the mouse pointer.

      setCursor (null);

      // Load images described by the game.tbl file. By convention,
      // .tbl (table) is specified as this file's extension.

      defineGraphics ("game.tbl");

      // The image size, which is 800 by 600, must be a multiple of the tile
      // size, which is 800 by 600.

      setBGImage ("background");
   }

   public void doFrame ()
   {
      // Move all alien sprites. For each sprite, Alien's move() method is
      // called.

      moveObjects ();

      // Checks for collisions between all alien sprites. If a collision
      // occurs, Alien's hit() method is called.

      checkCollision (Alien.COLID, Alien.COLID);

      // Generate a new alien sprite anywhere above the top of the screen.

      if (random (1, 50, 1) == 25)
          new Alien (random (0, pfWidth ()-32), -90, random (0.0, 1.0));
   }

   public static void main (String [] args)
   {
      // Run the game at a window size of 800 by 600 pixels.

      new Game (800, 600);
   }

   class Alien extends JGObject
   {
      final static int COLID = 1;

      Alien (double x, double y, double xdir)
      {
         // Create a unique Alien sprite at the specified position, using the
         // specified collision ID, and with the image defined by alien in
         // game.tbl.

         // If false was passed in the super() call below, only one alien
         // sprite could exist in the game. This sprite would only last until
         // a new alien sprite was created.

         super ("alien", true, x, y, COLID, "alien");

         // The alien sprite will not move until told to do so. The method
         // call below tells the alien sprite to move left or right (based on
         // xdir) and downwards.

         setDirSpeed ((xdir < 0.5) ? -1 : 1, 1, 1.0, 1.0);
      }

      public void move ()
      {
         // Reverse this alien sprite's current horizontal direction if it
         // runs into the left or right sides of the play field.

         if (x < 0)
             xdir = 1;
         else
         if (x > pfWidth ()-32)
             xdir = -1;

         // Reverse this alien sprite's current vertical direction if it runs
         // into the bottom or (just past the) top sides of the play field.

         if (y < -90)
             ydir = 1;
         else
         if (y > pfHeight ()-32)
             ydir = -1;
      }

      public void hit (JGObject obj)
      {
         // Create and register a unique explosion sprite positioned at the
         // alien's most recent coordinates. A collision identifier is not
         // necessary, which is why 0 is passed as a placeholder. The
         // explosion animation is defined by explo. It doesn't move anywhere, 
         // hence 0 is passed for the horizontal and vertical speeds. Finally,
         // the explosion will last for 32 frames.

         new JGObject ("explo", true, x, y, 0, "explo", 0, 0, 32);

         // Remove this alien sprite.

         remove ();

         // Remove the alien sprite that collided with this alien sprite.

         obj.remove ();
      }
   }
}

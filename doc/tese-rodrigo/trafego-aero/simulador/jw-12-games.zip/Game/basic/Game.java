// Game.java

import jgame.*;

public class Game extends JGEngine
{
   // Establish a virtual play field that is 100 pixels by 100 pixels. All
   // output in this play field is scaled to 800 by 600 pixels when the game
   // is run as an application. When the game is run as an applet, the output
   // is scaled to whatever window size is specified by the <applet> tag's
   // width and height parameters.

   final static int NTILESX = 1;
   final static int NTILESY = 1;
   final static int TILEW = 100;
   final static int TILEH = 100;

   public Game ()
   {
      initEngineApplet (NTILESX, NTILESY, TILEW, TILEH, null, null, null);
   }

   public Game (int width, int height)
   {
      initEngine (NTILESX, NTILESY, TILEW, TILEH, null, null, null, width,
                  height);
   }

   public void initGame ()
   {
   }

   public static void main (String [] args)
   {
      // Run the game at a window size of 800 by 600 pixels.

      new Game (800, 600);
   }
}

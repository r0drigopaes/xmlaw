// Game.java

import jgame.*;

public class Game extends JGEngine
{
   final static int NTILESX = 1;
   final static int NTILESY = 1;
   final static int TILEW = 800;
   final static int TILEH = 600;

   public Game ()
   {
      initEngineApplet (NTILESX, NTILESY, TILEW, TILEH, null, null, null);
   }

   public Game (int width, int height)
   {
      initEngine (NTILESX, NTILESY, TILEW, TILEH, null, null, null, width,
                  height);
   }

   public void initGame ()
   {
      // Load images described by the game.tbl file. By convention,
      // .tbl (table) is specified as this file's extension.

      defineGraphics ("game.tbl");

      // The image size, which is 800 by 600, must be a multiple of the tile
      // size, which is 800 by 600.

      setBGImage ("background");
   }

   public static void main (String [] args)
   {
      // Run the game at a window size of 800 by 600 pixels.

      new Game (800, 600);
   }
}
